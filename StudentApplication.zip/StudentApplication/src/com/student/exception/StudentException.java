package com.student.exception;

public class StudentException extends Exception {

	public StudentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StudentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 7278636172281449945L;

}
