package com.cg.banking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.exception.AccountException;
import com.cg.banking.util.DbConnection;



public class AccountDAOImpl implements IAccountDAO {

	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	
	@Override
	public List<BankingBean> getAccount(String customer_name) throws AccountException {
		
		List<BankingBean> list=new ArrayList<BankingBean>();
		
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapperAccount.VIEW);
			preparedStatement.setString(1, customer_name);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				
				BankingBean bb=new BankingBean();
				bb.setAccount_number(resultSet.getString(1));
				bb.setCustomer_name(resultSet.getString(2));
				bb.setAccount_type(resultSet.getString(3));
				bb.setAccount_location(resultSet.getString(4));
				bb.setBalance(resultSet.getFloat(5));
				list.add(bb);
				
			}

		} catch (SQLException e) {
			throw new AccountException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new AccountException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new AccountException(
						"Could not close the connection");
			}
		}
		return list;
	
	}

	@Override
	public float getBalance(String account_number) throws AccountException {
		float balance=0;
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapperAccount.BALANCE);
			preparedStatement.setString(1, account_number);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
			 balance=resultSet.getFloat(1);
			 
			}
		}catch (Exception e) {
			throw new AccountException(
					"Could not close the connection");
		}
		return balance;
	}

	@Override
	public boolean updateBalance(String account_number,float balance) throws AccountException {
		int records=0;
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapperAccount.UPDATEBALANCE);
			preparedStatement.setFloat(1, balance);
			preparedStatement.setString(2, account_number);
		
			 records=preparedStatement.executeUpdate();
			if(records>0){
				return true;
			}
			 
		}catch (Exception e) {
			throw new AccountException(
					"Could not Update the balance");
		}
		return false;
	}

	@Override
	public boolean insertTransaction(String account_number,float amount)
			throws AccountException {
		int records=0;
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapperAccount.INSERTTRANSACTION);
			
			
			preparedStatement.setString(1, "ATM DEBIT");
			preparedStatement.setFloat(2, amount);
			preparedStatement.setDate(3,Date.valueOf(LocalDate.now()) );
			preparedStatement.setString(4, account_number);		
			 records=preparedStatement.executeUpdate();
			if(records>0){
				return true;
			}
			 
		}catch (Exception e) {
			throw new AccountException(
					"Could not Update the transactions");
		}		
		return false;
	}

}
