package com.me.listener;

import java.util.Date;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

/**
 * Application Lifecycle Listener implementation class MyRequestListener
 *
 */
public class MyRequestListener implements ServletRequestListener {
	private long startTime;
	private long endTime;
    /**
     * Default constructor. 
     */
    public MyRequestListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletRequestListener#requestDestroyed(ServletRequestEvent)
     */
    public void requestDestroyed(ServletRequestEvent arg0) {
        // TODO Auto-generated method stub
    	endTime = System.currentTimeMillis();
    	System.out.println("Request destroyed at " + new Date());
    	System.out.println("The request lasted for " + (endTime - startTime)+" milliseconds"+"\n");    	
    }

	/**
     * @see ServletRequestListener#requestInitialized(ServletRequestEvent)
     */
    public void requestInitialized(ServletRequestEvent arg0) {
        // TODO Auto-generated method stub
    	startTime = System.currentTimeMillis();
    	System.out.println("Request initialized at " + new Date());    	
    }
	
}
