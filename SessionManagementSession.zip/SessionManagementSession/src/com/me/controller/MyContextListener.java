package com.me.controller;

import java.util.Date;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Application Lifecycle Listener implementation class MyContextListener
 *
 */
public class MyContextListener implements ServletContextListener {
	private long startTime;
	private long endTime;
    /**
     * Default constructor. 
     */
    public MyContextListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce) {
        // TODO Auto-generated method stub
    	startTime = System.currentTimeMillis();
    	System.out.println("Context initialized at " + new Date());
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce) {
        // TODO Auto-generated method stub
    	endTime = System.currentTimeMillis();
    	System.out.println("Context destroyed at " + new Date());
    	System.out.println("The web application lasted for " + (endTime - startTime)+" milliseconds");
    }	
}