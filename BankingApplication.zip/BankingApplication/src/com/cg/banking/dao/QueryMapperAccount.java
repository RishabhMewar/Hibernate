package com.cg.banking.dao;

public interface QueryMapperAccount {
	String VIEW = "SELECT account_number,customer_name,account_type,account_location,balance FROM account_details WHERE customer_name=?";
	String BALANCE="SELECT balance FROM account_details WHERE account_number=?";
	String UPDATEBALANCE="UPDATE account_details SET balance=? WHERE account_number=?";
	String INSERTTRANSACTION="INSERT INTO transaction_details values(transaction_id_seq.NEXTVAL,?,?,?,?)";
			
}
