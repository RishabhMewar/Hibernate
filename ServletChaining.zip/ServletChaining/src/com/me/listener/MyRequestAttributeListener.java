package com.me.listener;

import java.util.Date;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;

/**
 * Application Lifecycle Listener implementation class MyRequestAttributeListener
 *
 */
public class MyRequestAttributeListener implements ServletRequestAttributeListener {
	private long startTime;
	private long endTime;
	
    /**
     * Default constructor. 
     */
    public MyRequestAttributeListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletRequestAttributeListener#attributeAdded(ServletRequestAttributeEvent)
     */
    public void attributeAdded(ServletRequestAttributeEvent arg0) {
        // TODO Auto-generated method stub
    	startTime = System.currentTimeMillis();
    	System.out.println("Request attribute added at " + new Date());
    	System.out.println("Attribute name: "+arg0.getName());
    	System.out.println("Attribute value: "+arg0.getValue());
    }

	/**
     * @see ServletRequestAttributeListener#attributeRemoved(ServletRequestAttributeEvent)
     */
    public void attributeRemoved(ServletRequestAttributeEvent arg0) {
        // TODO Auto-generated method stub
    	endTime = System.currentTimeMillis();
    	System.out.println("Request attribute removed at " + new Date());
    	System.out.println("The request attribute lasted for " + (endTime - startTime)+" milliseconds"+"\n");
    	System.out.println("Attribute name: "+arg0.getName());
    	System.out.println("Attribute value: "+arg0.getValue());
    }

	/**
     * @see ServletRequestAttributeListener#attributeReplaced(ServletRequestAttributeEvent)
     */
    public void attributeReplaced(ServletRequestAttributeEvent arg0) {
        // TODO Auto-generated method stub
    	System.out.println("Request attribute modified at " + new Date());
    	System.out.println("Attribute name: "+arg0.getName());
    	System.out.println("Attribute value: "+arg0.getValue());
    	
    }
	
}
